let display = document.getElementById("display")

   function button(num) {
     display.value+=num
     
   }
   
   function results() {
     display.value=eval(display.value)
   }